Prepare a handoff for the other Claude Code sessions:

1. Run /smoke (build + scripts/smoke.sh) and make it green.
2. Commit all work on this lane's branch with a descriptive message.
3. Merge main into this branch, resolve conflicts, re-run the build.
4. Append to PROGRESS.md: what was completed, what remains in this lane, any blockers,
   and anything another lane must know (changed interfaces are forbidden — see CLAUDE.md
   hard rule 3 and 6 — so flag any interface pressure instead of changing it).
5. Merge this branch to main only if green.
