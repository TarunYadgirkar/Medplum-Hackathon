Run the project's verification suite and report results:

1. `npm run build` — must pass with zero errors.
2. Ensure a dev server is running on port 3000 (start one with `npm run dev` in the background if not).
3. `bash scripts/smoke.sh` — all checks must pass.

If anything fails, fix it before reporting done, and append the outcome to PROGRESS.md.
